#ifndef LOFREQ_INDEX_H
#define LOFREQ_INDEX_H

int main_faidx(int argc, char *argv[]);
int main_index(int argc, char *argv[]);
int main_idxstats(int argc, char *argv[]);

#endif
