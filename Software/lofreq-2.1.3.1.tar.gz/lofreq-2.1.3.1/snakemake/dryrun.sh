snakemake -T -p --dryrun --configfile cfg.yaml -s Snakefile
